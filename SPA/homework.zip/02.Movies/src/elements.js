
export const moviesContainer = document.getElementById('container')
export const homePage = document.getElementById('home-page');
export const addMovieButton = document.getElementById('add-movie-button');
export const movieSection = document.getElementById('movie');
export const sectionAddMovie = document.getElementById('add-movie');
export const movieExample = document.getElementById('movie-example');
export const editMovie = document.getElementById('edit-movie');
export const formLogin = document.getElementById('form-login');
export const formRegister = document.getElementById('form-sign-up');
export const welcomeEmail = document.getElementById('welcomeEmail');
export const logout = document.getElementById('logout');
export const login = document.getElementById('login');
export const register = document.getElementById('register');
export const submitBtn = document.getElementById('formSubmitButton');
export const registerFormular = document.getElementById('registerForm');
export const loginFormular = document.getElementById('loginFormular');
export const loginButton = document.getElementById('loginButton');