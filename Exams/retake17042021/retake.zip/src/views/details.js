import { html } from '../../node_modules/lit-html/lit-html.js';
import { getPetById } from '../api/data.js';
import { deletePet } from '../api/data.js';

const detailsTemplate = (data, onDelete) => html`
<section id="details-page" class="details">
    <div class="pet-information">
        <h3>Name: ${data.name}</h3>
        <p class="type">Type: ${data.type}</p>
        <p class="img"><img src=${data.imageUrl}></p>
        <div class="actions">
            <!-- Edit/Delete buttons ( Only for creator of this pet )  -->
            ${(data._ownerId === sessionStorage.userId)
        ? html`<a class="button" href="/edit/${data._id}">Edit</a>
            <a @click=${onDelete} class="button" href="javascript:void(0)">Delete</a>`
        :
        ''
        }
            <!-- Bonus -->
            <!-- Like button ( Only for logged-in users, which is not creators of the current pet ) -->
            ${(data._ownerId != sessionStorage.userId) ?
        html`<a class="button" href="#">Like</a>`
        : html``
    }

            <!-- ( for Guests and Users )  -->

            <!-- Bonus -->
        </div>
    </div>
    <div class="pet-description">
        <h3>Description:</h3>
        <p>${data.description}</p>
    </div>
</section>
`;

export async function detailsPage(ctx) {
    const data = await getPetById(ctx.params.id);
    ctx.render(detailsTemplate(data, onDelete));

    async function onDelete() {
        const confirmed = confirm('Are you sure you want to delete the item?');
        if (confirmed) {
            await deletePet(ctx.params.id);
            ctx.page.redirect('/');
        }
    }
}